</main>

<footer class="signature">
    <p>&copy; <?= date('Y') ?> Projet 3 - Bibliothèque - César et Cristhian - SIO1 2025</p>
</footer>
</body>
</html>
