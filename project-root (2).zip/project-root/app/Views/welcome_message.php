<?= view('templates/header', ['title' => 'Bienvenue']) ?>

<h1>Welcome to CodeIgniter 4!</h1>
<p>The page you are looking at is being generated dynamically by CodeIgniter.</p>

<?= view('templates/footer') ?>
