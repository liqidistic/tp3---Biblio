<?php

namespace App\Controllers;
use App\Models\DemandeModel;
use App\Models\LivreModel;
use App\Models\ExemplaireModel;
use App\Controllers\BaseController;

class DemandeController extends BaseController
{
    public function demander($cote_exemplaire)
    {
        $db = \Config\Database::connect();
        $matricule = session()->get('matricule');
    
        $builder = $db->table('demande');
        $builder->select('demande.*, livre.titre_livre');
        $builder->join('exemplaire', 'exemplaire.cote_exemplaire = demande.cote_exemplaire');
        $builder->join('livre', 'livre.code_catalogue = exemplaire.code_catalogue');
        $builder->where('demande.matricule_abonne', $matricule);
    
        $demandes = $builder->get()->getResultArray();
    
        return view('/mes_demandes', ['demandes' => $demandes]);
    }
    public function mesDemandes()
{
    $db = \Config\Database::connect();
    $matricule = session()->get('matricule');

    $builder = $db->table('demande');
    $builder->select('demande.*, livre.titre_livre');
    $builder->join('exemplaire', 'exemplaire.cote_exemplaire = demande.cote_exemplaire');
    $builder->join('livre', 'livre.code_catalogue = exemplaire.code_catalogue');
    $builder->where('demande.matricule_abonne', $matricule);

    $demandes = $builder->get()->getResultArray();

    return view('abonne/mes_demandes', ['demandes' => $demandes]);
}

}    